import { Component, OnInit } from "@angular/core";
import { UsersService } from "../users.service";

@Component({
  selector: "navbar-users",
  templateUrl: "./users.component.html",
  styleUrls: ["./users.component.css"],
})
export class UsersComponent implements OnInit {
  constructor(public usersService: UsersService) { }
  form;
  numPag = "0";
  ordine;
  conta;
  pagine;
  arra: any[] = [];
  users;
  totElement;
  modo;
  expanded
  ngOnInit() {
    this.usersService.getUsers("1", "12").subscribe((res: any) => {
      this.users = res.body;
      this.totElement = res.headers.get("x-total-count");
    });
  }

  stopPropagation(event) {
    event.stopPropagation();
  }

  cambiaPagina(p) {
    console.log("ev", p);
    this.numPag = p.pageIndex + 1;
    this.usersService
      .getUsers(this.numPag, p.pageSize)
      .subscribe((res: any) => {
        this.users = res.body;
        window.scrollTo(0, 0);
      });
  }
  cerca() {
    let el = document.getElementById("ids") as HTMLInputElement;
    this.usersService.getUserSearch(el.value).subscribe((res) => {
      this.users = res;
    });
  }

  order(element: string) {
    this.usersService.getUsersOrdered(this.numPag).subscribe((res: any) => {
      console.log(res);
      this.users = res;
    });

    /*  switch (element) {
      case "name":
        this.usersService
          .getUsersOrdered("name", this.numPag)
          .subscribe((res: any) => {
            console.log(res);
            this.users = res;
          });
        break;
      case "phone":
        this.usersService
          .getUsersOrdered("phone", this.modo)
          .subscribe((res: any) => {
            this.dataSource = res.body;
          });
        break;
      case "mail":
        this.usersService
          .getUsersOrdered("mail", this.modo)
          .subscribe((res: any) => {
            this.dataSource = res.body;
          });
        break;
      default:
        break;
    } */
  }
}
