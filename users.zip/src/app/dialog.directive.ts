import { Component, Directive, EventEmitter, HostListener, Output } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Directive({
  selector: '[usersDialog]'
})
export class DialogDirective {
  @Output() uClick = new EventEmitter();
  constructor(public dialog: MatDialog, private router: Router) { }

  @HostListener('click', ['$event'])
  clickEvent() {

    const dialogRef = this.dialog.open(DialogContent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
      if (result)
        this.router.navigateByUrl('/users')
    });
  }
}

@Component({
  selector: 'dialog-content',
  templateUrl: 'dialog-content.html',
})
export class DialogContent { }
