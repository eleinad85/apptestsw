import { Component } from "@angular/core";
import { UsersService } from "src/app/users.service";
import { MatSnackBar } from "@angular/material/snack-bar";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { user } from "../users.interface";
import { MatDialog } from '@angular/material/dialog';
import { DialogContent } from '../dialog.directive';
@Component({
  selector: "app-addEdit",
  templateUrl: "./addEdit.component.html",
  styleUrls: ["./addEdit.component.scss"],
})
export class AddEditComponent {
  user: user;
  form: FormGroup;
  focusOut
  constructor(
    public userService: UsersService,
    private _snackBar: MatSnackBar,
    private router: Router,
    public dialog: MatDialog
  ) {
    this.form = new FormGroup({
      name: new FormControl(this.userService.utente ? this.userService.utente.name : "", Validators.required),
      mail: new FormControl(this.userService.utente ? this.userService.utente.mail : "",
        [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      phone: new FormControl(this.userService.utente ? this.userService.utente.phone : ""),
    });
  }

  controlla(lettera) {
    console.log(lettera)

    if ((lettera.keyCode < 48 && lettera.keyCode != 8)
      || lettera.keyCode > 57
      && lettera.keyCode < 96 || lettera.keyCode > 105)
      lettera.preventDefault()
  }

  openDialog() {
    const dialogRef = this.dialog.open(DialogContent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
      if (result)
        this.addEditUser()
    });
  }
  addEditUser() {
    if (this.userService.utente == null) {
      this.userService.addUsers(this.form.value).subscribe((res) => {
        this._snackBar.open("salvataggio effettuato", "", {
          duration: 4000,
        });

        this.userService.idUtente = res.id;
        this.router.navigateByUrl("/users/" + res.id);
      });
    } else {
      this.userService
        .editUsers(this.userService.idUtente, this.form.value)
        .subscribe((res) => {
          this._snackBar.open("salvataggio effettuato", "", {
            duration: 4000,
          });
          this.userService.idUtente = res.id;
          this.router.navigateByUrl("/users/" + res.id);
        });
    }
  }
}

