import { Component } from '@angular/core';

@Component({
  selector: 'users-empty-route',
  template: '',
})
export class EmptyRouteComponent {
}
