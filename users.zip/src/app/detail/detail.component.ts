import { Component, OnInit } from "@angular/core";
import { UsersService } from "src/app/users.service";
@Component({
  selector: "navbar-detail",
  templateUrl: "./detail.component.html",
  styleUrls: ["./detail.component.css"],
})
export class DetailComponent implements OnInit {
  constructor(public userServ: UsersService) {}
  user;

  ngOnInit() {
    this.userServ.getUser(this.userServ.idUtente).subscribe((res) => {
      console.log("ute", res);
      this.user = res;
    });
  }
}
