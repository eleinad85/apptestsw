import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
@Injectable({
  providedIn: "root",
})
export class UsersService {
  constructor(private http: HttpClient) { }
  idUtente;
  utente;
  getUserCount(): Observable<Array<any>> {
    return this.http.get<Array<any>>("http://localhost:3000/users");
  }

  getUsers(page: string, limit: string): Observable<Array<any>> {
    return this.http.get<Array<any>>(
      "http://localhost:3000/users?_page=" + page + "&_limit=" + limit,
      { observe: "response" as "body" }
    );
  }

  getUser(id): Observable<any> {
    return this.http.get<any>("http://localhost:3000/users/" + id);
  }
  getUserSearch(element): Observable<any> {
    return this.http.get<any>("http://localhost:3000/users?q=" + element);
  }

  addUsers(user: any): Observable<any> {
    let headers = new HttpHeaders().set("Content-Type", "application/json");
    return this.http.post<any>("http://localhost:3000/users", user, {
      headers: headers,
    });
  }
  editUsers(id: string, user: any): Observable<any> {
    let headers = new HttpHeaders().set("Content-Type", "application/json");
    return this.http.put<any>("http://localhost:3000/users/" + id, user, {
      headers: headers,
    });
  }
  /* 'users?_page=2&_limit=4?_sort=name&_order=asc' */
  getUsersOrdered(pagina): Observable<Array<any>> {
    return this.http.get<Array<any>>(
      "http://localhost:3000/users?_page=" +
      pagina +
      "&_limit=12&_sort=name&_order=asc"
    );
  }
}
