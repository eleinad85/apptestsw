export interface user {
  name: string;
  phone: string;
  mail?: string;
}
