import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEditComponent } from './addEdit/addEdit.component';
import { DetailComponent } from './detail/detail.component';
import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { UsersComponent } from './users/users.component';
import { DialogDirective } from './dialog.directive';



const routes: Routes = [
  { path: 'users', component: UsersComponent },
  { path: 'users/new', component: AddEditComponent },
  { path: 'users/:id/edit', component: AddEditComponent },
  { path: 'users/:id', component: DetailComponent },
  { path: '**', component: EmptyRouteComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule],


})
export class AppRoutingModule { }
